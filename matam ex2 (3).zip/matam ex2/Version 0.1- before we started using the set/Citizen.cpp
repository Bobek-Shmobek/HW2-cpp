
#include <iostream>
#include "Citizen.h"

using std::string;
using namespace mtm;

//Constructor
Citizen::Citizen(double new_id, string new_first_name, string new_last_name, double new_birth_year):
id(new_id),
first_name(new_first_name),
last_name(new_last_name),
birth_year(new_birth_year)
{
  
}

//Copy Constructor
Citizen::Citizen(const Citizen& citizen_to_copy):
id(citizen_to_copy.getId()), 
first_name(citizen_to_copy.getFirstName()), 
last_name(citizen_to_copy.getLastName()), 
birth_year(citizen_to_copy.getBirthYear())
{
    
}


//**//
//Methods start here

double Citizen::getId() const
{
    return this->id;
}

string Citizen::getFirstName() const
{
    return this->first_name;
}

string Citizen::getLastName() const
{
    return this->last_name;
}

double Citizen::getBirthYear() const
{
    return this->birth_year;
}


//Methods end here
//**//


//**//
//Compare operators start here

bool operator <(const Citizen& Citizen1, const Citizen& Citizen2)
{
    return Citizen1.getId() < Citizen2.getId();
}

bool operator >(const Citizen& Citizen1, const Citizen& Citizen2)
{
    return Citizen1.getId() > Citizen2.getId();
}

bool operator ==(const Citizen& Citizen1, const Citizen& Citizen2)
{
    return Citizen1.getId() == Citizen2.getId();
}

bool operator <=(const Citizen& Citizen1, const Citizen& Citizen2)
{
    return Citizen1.getId() <= Citizen2.getId();
}

bool operator >=(const Citizen& Citizen1, const Citizen& Citizen2)
{
    return Citizen1.getId() >= Citizen2.getId();
}

bool operator !=(const Citizen& Citizen1, const Citizen& Citizen2)
{
    return Citizen1.getId() != Citizen2.getId();
}

//Compare operators end here
//**//


