#include <set>
#include <iostream>
#include "Citizen.h"
#include "Skill.h"
#include "Employee.h"
#include "Manager.h"
#include "City.h"
#include "Workplace.h"


using std::string;
using std::set;
using namespace mtm;


//Constructor
City::City(string new_city_name) :
city_name(new_city_name), city_citizen_set(), city_faculty_set(), city_workplace_set()
{

}




//**//
//Methods start here

//add to sets methods
void City::addEmployee(double new_id, string new_first_name, string new_last_name, double new_birth_year)
{
    Employee new_employee = Employee(new_id,  new_first_name,  new_last_name,  new_birth_year);
    city_citizen_set.insert(new_employee);
}

void City::addManager(double new_id, string new_first_name, string new_last_name, double new_birth_year)
{
    Manager new_manager = Manager(new_id, new_first_name, new_last_name, new_birth_year);
    city_citizen_set.insert(new_manager);
}

void City::addFaculty(double new_id, Skill new_skill_to_teach, int new_added_points)
{
    Faculty new_faculty = Faculty(new_id, new_skill_to_teach, new_added_points);
    city_faculty_set.insert(new_faculty);
}

void City::createWorkplace(double new_id, string new_name, int new_WorkersSalary, int new_ManagersSalary)
{
    Workplace new_workplace = Workplace(new_id, new_name, new_WorkersSalary, new_ManagersSalary);
}

void City::teachAtFaculty(int employee_id,int faculty_id)
{
    mathcing_faculty = 
}


//hiring methods
template <class Condition>
void City::hireEmployeeAtWorkplace(Condition condition, int employee_id, int manager_id, int workplace_id)
void City::hireManagerAtWorkplace(int manager_id, int workplace_id)

//firing methods
void City::fireEmployeeAtWorkplace(int employee_id, int manager_id, int workplace_id)
void City::fireManagerAtWorkplace(int manager_id, int workplace_id)


void City::getAllAboveSalary();// how to declare this!!!!!

void City::isWorkingInTheSameWorkplace(int employee1_id, int employee2_id )

void City::printAllEmployeesWithSkill();// how to declare this!!!!!


//Methods end here
//**//

//self made Methods

Faculty* City::getFacultyById(int faculty_id);