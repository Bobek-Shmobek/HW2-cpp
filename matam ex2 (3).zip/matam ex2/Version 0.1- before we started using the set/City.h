#ifndef UNTITLED_CITY_H
#define UNTITLED_CITY_H
#include <set>
#include <iostream>
#include "Citizen.h"
#include "Skill.h"
#include "Employee.h"
#include "Manager.h"
#include "Faculty.h"


using std::string;
using std::set;

namespace mtm
{

    class City
    {
        string city_name;

        set <Citizen> city_citizen_set;
        set <Faculty> city_faculty_set;
        set <Workplace> city_workplace_set;

        public:

        City(string new_city_name);
        ~City() =  default;

        void addEmployee(double new_id, string new_first_name, string new_last_name, double new_birth_year);
        void addManager(double new_id, string new_first_name, string new_last_name, double new_birth_year);
        void addFaculty(double new_id, Skill new_skill_to_teach, int new_added_points);
        void createWorkplace(double new_id, string new_name, int new_WorkersSalary, int new_ManagersSalary);
        void teachAtFaculty(int employee_id,int faculty_id);

        template <class Condition>
        void hireEmployeeAtWorkplace(Condition condition, int employee_id, int manager_id, int workplace_id);
        void hireManagerAtWorkplace(int manager_id, int workplace_id);

        void fireEmployeeAtWorkplace(int employee_id, int manager_id, int workplace_id);
        void fireManagerAtWorkplace(int manager_id, int workplace_id);


        void getAllAboveSalary();// how to declare this!!!!!

        void isWorkingInTheSameWorkplace(int employee1_id, int employee2_id );

        void printAllEmployeesWithSkill();// how to declare this!!!!!

        //Self made methods

        Faculty* getFacultyById(int faculty_id);
    

        
        
    };
}






#endif //UNTITLED__FACULTY_H