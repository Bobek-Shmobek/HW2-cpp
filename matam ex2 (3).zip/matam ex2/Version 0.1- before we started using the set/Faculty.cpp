#include <set>
#include <iostream>
#include "Citizen.h"
#include "Skill.h"
#include "Employee.h"
#include "Manager.h"
#include "Workplace.h"
#include "Faculty.h"



using std::string;
using std::set;
using namespace mtm;


//Constructor
Faculty::Faculty(double new_id, Skill new_skill_to_teach, int new_added_points) :
id(new_id), skill_to_teach(new_skill_to_teach), added_points(new_added_points)
{

}


//**//
//Methods start here

int Faculty::getAddedPoints() const
{
    return this->added_points;
}

int Faculty::getId() const
{
    return this->id;
}
Skill Faculty::getSkill() const
{
    return this->skill_to_teach;
}

void Faculty::teach(Employee& employee)
{
//add this!!!!!

}

//Methods end here
//**//