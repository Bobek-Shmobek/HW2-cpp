#ifndef UNTITLED_FACULTY_H
#define UNTITLED_FACULTY_H
#include <set>
#include <iostream>
#include "Citizen.h"
#include "Skill.h"
#include "Employee.h"
#include "Manager.h"


using std::string;
using std::set;

namespace mtm
{

    class Faculty
    {
        int id;
        Skill skill_to_teach;
        int added_points;

        public:


        Faculty(double new_id, Skill new_skill_to_teach, int new_added_points);
        ~Faculty() =  default;

        int getAddedPoints() const;
        int getId() const;
        Skill getSkill() const;
        void teach(Employee& employee);
        
    };
}






#endif //UNTITLED__FACULTY_H