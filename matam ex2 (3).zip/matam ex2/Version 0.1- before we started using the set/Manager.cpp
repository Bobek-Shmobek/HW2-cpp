#include <set>
#include <iostream>
#include "Citizen.h"
#include "Skill.h"
#include "Employee.h"
#include "Manager.h"


using std::string;
using std::set;
using namespace mtm;


//Constructor
Manager::Manager(double new_id, string new_first_name, string new_last_name, double new_birth_year) :
Citizen(new_id, new_first_name, new_last_name, new_birth_year), salary(0), manager_employee_set()
{

}



//**//
//Methods start here

int Manager::getSalary() const
{
    return this->salary;
}

void Manager::setSalary(int raise) 
{
    this->salary += raise;
    return;

}

Citizen* Manager::clone() const
{
    return new Manager(*this);
}

//Methods end here
//**//