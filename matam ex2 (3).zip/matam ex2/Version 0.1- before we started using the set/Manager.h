#ifndef UNTITLED_MANAGER_H
#define UNTITLED_MANAGER_H
#include <set>
#include <iostream>
#include "Citizen.h"
#include "Skill.h"
#include "Employee.h"


using std::string;
using std::set;

namespace mtm
{
    class City;

    class Manager  : public Citizen 
    {
        int salary;
        set <*Employee> manager_employee_set;

        public:
        
        Manager(double new_id, string new_first_name, string new_last_name, double new_birth_year);
        ~Manager() =  default;

        int getSalary() const;
        void setSalary(int raise);
        void addEmployee(const Employee  employee_to_add);
        void removeEmployee(int id);
        void printShort();//add this!!!!
        void printLong();//add this!!!

        virtual Citizen* clone() const override;
    };

}






#endif //UNTITLED__MANAGER_H