#include <iostream>
#include "Skill.h"

using std::string;
using namespace mtm;


//Constructor
Skill::Skill(double new_id, string new_name, double new_required_points):
id(new_id),
name(new_name),
required_points(new_required_points)
{

}

//Copy Constructor
Skill::Skill(const Skill& skill_to_copy):
id(skill_to_copy.getId()), 
name(skill_to_copy.getName()), 
required_points(skill_to_copy.getRequiredPoints())
{

}




//**//
//Methods start here

double Skill::getId() const
{
    return this->id;
}

string Skill::getName() const
{
    return this->name;
}

double Skill::getRequiredPoints() const
{
    return this->required_points;
}

//Methods end here
//**//


//**//
//Compare operators start here

bool operator ==(const Skill& skill1, const Skill& skill2)
{
    return skill1.getId() == skill2.getId();
}

bool operator <(const Skill& skill1, const Skill& skill2)
{
    return skill1.getId() < skill2.getId();
}

bool operator >(const Skill& skill1, const Skill& skill2)
{
    return skill1.getId() > skill2.getId();
}

bool operator <=(const Skill& skill1, const Skill& skill2)
{
    return skill1.getId() <= skill2.getId();
}

bool operator >=(const Skill& skill1, const Skill& skill2)
{
    return skill1.getId() >= skill2.getId();
}

bool operator !=(const Skill& skill1, const Skill& skill2)
{
    return skill1.getId() != skill2.getId();
}

//Compare operators end here
//**//


//**//
//increase or decrease operators start here.
void Skill::operator ++(int)
{
    this->required_points++;
    return;
}

void Skill::operator +=(int given_amount)
{
    if(given_amount < 0)
    {
        //handle negetive amount!
    }
    this->required_points =+ given_amount;
    return;
}

void operator +(Skill& skill, int given_amount)
{
    skill += given_amount;
}

void operator +(int given_amount, Skill& skill)
{
    skill += given_amount;
}

//increase or decrease operators end here.
//**//
