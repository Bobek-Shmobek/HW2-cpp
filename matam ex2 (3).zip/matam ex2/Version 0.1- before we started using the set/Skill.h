#ifndef UNTITLED_SKILL_H
#define UNTITLED_SKILL_H
#include <iostream>


using std::string;

namespace mtm{


class Skill {
 
    double id;
    string name;
    double required_points;
    
    public:

    Skill(double id, string name, double required_points);
    Skill(const Skill& skill_to_copy);
    ~Skill() =  default;

    double getId() const;
    string getName() const;
    double getRequiredPoints() const;


    //increase or decrease operators.
    //** make sure ++ from the right doesnt work.
    void operator ++(int);
    void operator +=(int given_amount);


};

//Compare operators by id
bool operator ==(const Skill& skill1, const Skill& skill2);
bool operator <(const Skill& skill1, const Skill& skill2);
bool operator >(const Skill& skill1, const Skill& skill2);
bool operator <(const Skill& skill1, const Skill& skill2);
bool operator !=(const Skill& skill1, const Skill& skill2);
bool operator <=(const Skill& skill1, const Skill& skill2);
bool operator >=(const Skill& skill1, const Skill& skill2);


//increase or decrease operators. by required_points
void operator +(Skill& skill, int given_amount);
void operator +(int given_amount, Skill& skill);

}

#endif //UNTITLED_SKILL_H