#include <set>
#include <iostream>
#include "Citizen.h"
#include "Skill.h"
#include "Employee.h"
#include "Manager.h"
#include "Workplace.h"


using std::string;
using std::set;
using namespace mtm;


//Constructor
Workplace::Workplace(double new_id, string new_name, int new_WorkersSalary, int new_ManagersSalary) :
id(new_id), name(new_name), WorkersSalary(new_WorkersSalary), ManagersSalary(new_ManagersSalary), workplace_manager_set()
{

}




//**//
//Methods start here

void Workplace::hireManager(Manager* manager)
{

}

void Workplace::fireEmployee(int employee_to_fire_id)
{

}

void Workplace::fireManager(int manager_to_fire_id)
{

}

//Methods end here
//**//