#ifndef UNTITLED_WORKPLACE_H
#define UNTITLED_WORKPLACE_H
#include <set>
#include <iostream>
#include "Citizen.h"
#include "Skill.h"
#include "Employee.h"
#include "Manager.h"


using std::string;
using std::set;

namespace mtm
{

    class Workplace
    {
        int id;
        string name;
        int WorkersSalary;
        int ManagersSalary;


        set <*Manager> workplace_manager_set;

        public:


        Workplace(double new_id, string new_name, int new_WorkersSalary, int new_ManagersSalary);
        ~Workplace() =  default;

        template <class Condition>
        void hireEmployee(Condition condition, Employee* employee, int hiring_manager_id);
        void hireManager(Manager* manager);
        void fireEmployee(int employee_to_fire_id);
        void fireManager (int manager_to_fire_id);

        //add print workplace!!!!
    };
    
    template <class Condition>
    void hireEmployee(Condition condition, Employee* employee, int hiring_manager_id)
    {

    }

}







#endif //UNTITLED__WORKPLACE_H